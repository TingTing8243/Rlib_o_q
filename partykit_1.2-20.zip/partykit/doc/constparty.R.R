### R code from vignette source 'constparty.R'

